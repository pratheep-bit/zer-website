# Zerreta Educational Platform

A modern, innovative educational platform dedicated to transforming learning experiences through technology.

## Deployment

This website is configured for deployment on Vercel.

### Development

To run the site locally:

```bash
npm install
npm run dev
```

### Production Deployment

The site is configured for automatic deployment on Vercel. 